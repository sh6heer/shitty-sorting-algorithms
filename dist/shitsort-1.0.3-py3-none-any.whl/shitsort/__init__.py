from shitsort.bogo import bogosort
from shitsort.multibogo import multibogosort
